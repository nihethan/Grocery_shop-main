package com.example.groceryshop.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller

public class ModelViewController {
  @GetMapping("/home")
  public ModelAndView showHome() {
	return new ModelAndView("home");
  }
  
}
