package com.example.groceryshop.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.groceryshop.entity.OrderEntity;


public interface OrderRepository extends JpaRepository<OrderEntity,String> {
	@Query(value="SELECT * FROM order_table WHERE customer_email=:customerMail",nativeQuery=true)	
	public List<OrderEntity> findByEmail(@Param("customerMail") String customerMail);
	
}
