package com.example.groceryshop.serviceimpl;

import org.springframework.stereotype.Service;

import com.example.groceryshop.dao.OrderViewRepository;
import com.example.groceryshop.dto.ResponseDto;
import com.example.groceryshop.service.OrderViewService;

import lombok.Data;

@Service
@Data
public class OrderViewServiceImpl implements OrderViewService {
	private final OrderViewRepository orderViewRepository;
	
	@Override
	public ResponseDto deleteOrderProduct(String productId) {
		// TODO Auto-generated method stub
		ResponseDto response=new ResponseDto();
		try {
			if(orderViewRepository.existsById(productId)) {
				//System.out.print(productId);
				orderViewRepository.deleteOrderProduct(productId);
			response.setMessage("Deleted Successfully");
			response.setStatus(200);
			}}
			catch(Exception e) {
				response.setMessage("Product is not in the Table");
				throw e;
			}
		return response;
		}

	@Override
	public ResponseDto deleteOrderViewByOrderId(String orderId) {
		// TODO Auto-generated method stub
		ResponseDto response=new ResponseDto();
		//System.out.print("try");
		try {
			
			//	System.out.print("In");
				orderViewRepository.deleteOrderId(orderId);
			
			response.setMessage("Deleted Successfully");
			response.setStatus(200);
			
		
		}
		catch(Exception e) {
			throw e;
		}
		return response;
	}
}
