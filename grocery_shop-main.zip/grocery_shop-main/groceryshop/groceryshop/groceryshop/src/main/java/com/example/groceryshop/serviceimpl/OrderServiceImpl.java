package com.example.groceryshop.serviceimpl;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

//import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
//import org.springframework.web.bind.annotation.RequestParam;

import com.example.groceryshop.dao.CustomerDetailsRepository;
import com.example.groceryshop.dao.OrderRepository;
import com.example.groceryshop.dao.OrderViewRepository;
import com.example.groceryshop.dao.ProductRepository;

import com.example.groceryshop.dto.OrderDto;
import com.example.groceryshop.dto.OrderProductDto;
import com.example.groceryshop.dto.ResponseDto;
import com.example.groceryshop.dto.ViewOrderDto;
//import com.example.groceryshop.entity.CustomerDetailsEntity;
import com.example.groceryshop.entity.OrderEntity;
import com.example.groceryshop.entity.OrderViewEntity;
import com.example.groceryshop.entity.ProductEntity;
import com.example.groceryshop.service.OrderService;

import lombok.Data;
@Service
@Data
public class OrderServiceImpl implements OrderService {
private final OrderRepository orderRepository;

private final ProductRepository productRepository;
private final CustomerDetailsRepository customerDetailsRepository;
private final OrderViewRepository orderViewRepository;
	
	@Override
	public ResponseDto createOrder(OrderDto orderDto) {
		// TODO Auto-generated method stub
		ResponseDto response=new ResponseDto();
		ProductEntity product=new ProductEntity();
	
		try{
	//	CustomerDetailsEntity customer=new CustomerDetailsEntity(); 
			OrderEntity order=new OrderEntity();
			if(orderDto.getOrderId()==null ) {
					
                         order.setOrderStatus(orderDto.getOrderStatus());
						 order.setCustomerMail(orderDto.getCustomerMail());
						 order.setTotalAmount(orderDto.getTotalAmount()); 
						 OrderEntity savedOrders= orderRepository.save(order);
						
										 
	              	                 
	                 for(OrderProductDto item:orderDto.getProductOrder()) {
	                	// System.out.println(productId);
	                	  OrderViewEntity orderView=new OrderViewEntity();
	                	Optional<ProductEntity> optionProduct=productRepository.findById(item.getProductId());
	                	if(optionProduct.isPresent()) {
	                		

	                	 orderView.setOrderId(savedOrders.getOrderId());
	                	 product=optionProduct.get();
	                	 orderView.setProductId(item.getProductId());
	                	// System.out.println(item.getProductId());
                	     orderView.setProductName(product.getProductName());
                	   //  System.out.println(product.getProductName());
	                	 orderView.setProductMRP(product.getProductMRP());
	                	 orderView.setProductQuantity(item.getQuantity());
	                	// System.out.print(item.getQuantity()+"here");
	                	 orderView.setProductPrice(product.getProductPrice());
	                	 orderView.setProductUnit(product.getProductUnit());
	                	 orderView.setProductTax(product.getProductTax());
	                	 orderView.setSingleProductPrice((item.getQuantity())*(product.getProductPrice()));
	                	 orderViewRepository.save(orderView);
	                	// orderView.setTolalAmount(product.getTotalAmount());
	                   //  totalPrice+=((item.getQuantity())*(product.getProductPrice()));
	                    // System.out.println(item.getQuantity());
	                    // System.out.println(product.getProductPrice());
	                //	 orderViewList.add(orderView);
	                	
	                
	                	}
	               		                	
	                 }
	             
	                  
	             
                      
                      
			            response.setMessage("Order Placed created successfully");
			            response.setStatus(200);
			  
			}
		} 
		catch(Exception e) {
			throw e;
		}
		return response;
	}

//	@Override
//	public OrderDto getById(String orderId) {
//		// TODO Auto-generated method stub
//		OrderDto orderDto=new OrderDto();
//		
//		try {
//			OrderEntity order=new OrderEntity();
//			//OrderViewEntity orderView=new OrderViewEntity()
//			
//			OrderViewEntity orderView=new OrderViewEntity();
//			Optional<OrderEntity> optionOrder=orderRepository.findById(orderId);
//			if(optionOrder.isPresent()) {
//				order=optionOrder.get();
//				orderDto.setOrderId(order.getOrderId());
//				orderDto.setCustomerId(order.getCustomerId());
//				orderDto.setDateOfPurchase(order.getDateOfPurchase());
//			
//				orderDto.setOrderStatus(true);
//				orderDto.setSetTotalAmount(order.getTotalAmount());
//				
//				List<ViewOrderDto> viewOrderDtoList=new ArrayList<>(); 
//				
//				orderViewRepository.getOrderViewTableElementById(orderId);
//				Optional<ViewOrderEntity>
//              for(ViewOrderEntity viewOrder:)
//			    orderDto.setProductName(orderView.getProductName());
//				orderDto.setProductPrice(orderView.getProductPrice());
//				orderDto.setProductMRP(orderView.getProductMRP());
//				orderDto.setProductTax(orderView.getProductTax());
//				orderDto.setProductQuantity(orderView.getProductQuantity());
//				orderDto.setProductUnit(orderView.getProductUnit());
//				
//			}
//		}
//		catch(Exception e) {
//			
//		}
//		return orderDto;
//	}



	@Override
	public ResponseDto deleteOrder(String orderId) {
		//System.out.print("Order Id "+orderId);
		// TODO Auto-generated method stub
		ResponseDto response=new ResponseDto();
		try {
			
			if(orderRepository.existsById(orderId)) {
				orderRepository.deleteById(orderId);
//				if(orderViewRepository.existsById(orderId)) {
//				orderViewRepository.deleteById(orderId);
			
			response.setMessage("Deleted Successfully");
			response.setStatus(200);
			
		}}
		//}
		catch(Exception e) {
			throw e;
		}
		return response;
	}

@Override
public List<ViewOrderDto> getById(String orderId) {
	// TODO Auto-generated method stub
//	OrderViewEntity order=new OrderViewEntity();
	List<OrderViewEntity> orderViewList=orderViewRepository.getOrderViewTableElementById(orderId);
	
	List<ViewOrderDto> viewOrderDtoList=new ArrayList<>();
	
	try {
		OrderEntity orderid=new OrderEntity();
		
		for(OrderViewEntity entity:orderViewList) {
			ViewOrderDto viewOrderDto=new ViewOrderDto();
			Optional<OrderEntity> optionOrder=orderRepository.findById(orderId);
        	
			if(optionOrder.isPresent()) {
			orderid=optionOrder.get();
			viewOrderDto.setProductMRP(entity.getProductMRP());
			
			viewOrderDto.setProductName(entity.getProductName());
			viewOrderDto.setOrderId(orderid.getOrderId());
			viewOrderDto.setProductPrice(entity.getProductPrice());
			viewOrderDto.setProductQuantity(entity.getProductQuantity());
			viewOrderDto.setProductUnit(entity.getProductUnit());
			viewOrderDto.setSingleProductTotalPrice(entity.getSingleProductPrice());
			viewOrderDto.setProductTax(entity.getProductTax());
			
			viewOrderDtoList.add(viewOrderDto);
		}
		}
		return viewOrderDtoList;
	}
	catch(Exception e) {
		throw e;
	}
}

@Override
public ResponseDto deleteAllOrder() {
	// TODO Auto-generated method stub
	ResponseDto response=new ResponseDto();
	try {
		orderRepository.deleteAll();
		orderViewRepository.deleteAll();
		response.setMessage("Deleted Successfully");
		response.setStatus(200);
	}
	catch(Exception e) {
		throw e;
	}
	return response;
}

@Override
public OrderDto getOrderById(String orderId) {
	// TODO Auto-generated method stub
	
	OrderDto orderDto=new OrderDto();
	OrderEntity order=new OrderEntity();
	try {
		Optional<OrderEntity> optionOrder=orderRepository.findById(orderId);
		if(optionOrder.isPresent()) {
			order=optionOrder.get();
			orderDto.setOrderId(order.getOrderId());
			orderDto.setCustomerMail(order.getCustomerMail());
			orderDto.setTotalAmount(order.getTotalAmount());
			orderDto.setOrderStatus(order.getOrderStatus());
			orderDto.setDateOfPurchase(order.getDateOfPurchase());
			}
		return orderDto;
		
	}
	catch(Exception e) {
		throw e;
	}
	
}



@Override
public List<OrderDto> getAllOrder() {
	// TODO Auto-generated method stub
	try {
		List<OrderEntity> orderList = orderRepository.findAll();

		List<OrderDto> orderDtoList = new ArrayList<OrderDto>();

		orderList.forEach(val -> {

			OrderDto orderDto = new OrderDto();
			orderDto.setOrderId(val.getOrderId());
			orderDto.setCustomerMail(val.getCustomerMail());
			orderDto.setDateOfPurchase(val.getDateOfPurchase());
			orderDto.setOrderStatus(val.getOrderStatus());
			
			
			 orderDtoList.add(orderDto);
			

		});

		return orderDtoList;

	}
	catch (Exception e) {
		throw e;
	}
}

@Override
public List<OrderDto> getOrderByMail(String customerMail) {
	// TODO Auto-generated method stub
	
	List<OrderDto> orderDtoList=new ArrayList<>();
	List<OrderEntity> order = orderRepository.findByEmail(customerMail);
	//System.out.println(order);
if(order==null) {
	return null;
}       
order.forEach(val -> {
	
OrderDto orderDto=new OrderDto(); 
orderDto.setOrderId(val.getOrderId());
		orderDto.setDateOfPurchase(val.getDateOfPurchase());
		orderDto.setOrderStatus(val.getOrderStatus());
		orderDto.setTotalAmount(val.getTotalAmount());
		 orderDtoList.add(orderDto);
});
	return orderDtoList;
}


}


