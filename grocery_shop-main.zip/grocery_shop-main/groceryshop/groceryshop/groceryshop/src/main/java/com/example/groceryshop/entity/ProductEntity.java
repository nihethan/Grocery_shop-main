package com.example.groceryshop.entity;

import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name="product")
@Data
public class ProductEntity {
@Id
@UuidGenerator
@Column(name="product_id")
	private String productId;
@Column(name="product_name")
	  private String productName;
@Column(name="product_unit")
	  private int productUnit;
@Column(name="product_mrt")
	  private int productMRP;
@Column(name="product_price")
	  private int productPrice;
@Column(name="product_tax")
	  private int productTax;
}
