package com.example.groceryshop.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.groceryshop.dto.ProductDto;
import com.example.groceryshop.dto.ResponseDto;
import com.example.groceryshop.service.ProductService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api")
@CrossOrigin( origins="*")
@RequiredArgsConstructor
public class ProductController {
	private final ProductService productService;

	@PostMapping("/products")
	public ResponseEntity<ResponseDto> createProduct(@RequestBody ProductDto productDto) {
		return ResponseEntity.ok(productService.createProduct(productDto));
	}

	@GetMapping("/allproducts")
	public ResponseEntity<List<ProductDto>> getAllProduct() {
		return ResponseEntity.ok(productService.getAllProduct());
	}

	@GetMapping("/productname")
	public ResponseEntity<ProductDto> getProductByName(@RequestParam("productName") String productName) {
		return ResponseEntity.ok(productService.getProductByName(productName));
	}
	
    @GetMapping("/productnameexist")
    public  ResponseEntity<Boolean> checkProductExists(@RequestParam String productName){
    	boolean exist=productService.checkProductExists(productName);
    	return ResponseEntity.ok(exist);
    }

	@DeleteMapping("/delete")
	public ResponseEntity<ResponseDto> deleteProductById(@RequestParam("productId") String productId) {
		return ResponseEntity.ok(productService.deleteProductById(productId));

	}
	
	@DeleteMapping("/deleteall")
	public ResponseEntity<ResponseDto> deleteAllProducts(){
		return ResponseEntity.ok(productService.deleteAllProducts());
	}

}
