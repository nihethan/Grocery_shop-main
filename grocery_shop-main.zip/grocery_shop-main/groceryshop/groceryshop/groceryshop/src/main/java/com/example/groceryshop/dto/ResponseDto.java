package com.example.groceryshop.dto;

import lombok.Data;

@Data
public class ResponseDto {
	private String message;
	   private int status;
}
