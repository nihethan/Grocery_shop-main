package com.example.groceryshop.dto;

import java.time.LocalDate;

import lombok.Data;

@Data
public class ViewOrderDto {
	 private String customerId;
	 private LocalDate dateOfPurchase; 
	 private String productId;
	 private int productTax;
	 private int productPrice;
	 private int productMRP;
	 private int productUnit;
	 private String productName;
     private int productQuantity;
     private boolean orderStatus;
     private int  setTotalAmount;
     private String orderId;
     private int singleProductTotalPrice;
}
