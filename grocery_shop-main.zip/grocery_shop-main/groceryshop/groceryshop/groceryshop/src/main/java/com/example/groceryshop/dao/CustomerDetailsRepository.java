package com.example.groceryshop.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.groceryshop.entity.CustomerDetailsEntity;

public interface CustomerDetailsRepository extends JpaRepository<CustomerDetailsEntity,String> {

	@Query(value="SELECT COUNT(*)>0 FROM customer_details WHERE LOWER(TRIM(customer_email))=LOWER(TRIM(:customerEmail))", nativeQuery=true)
	public boolean existByCustomerEmail(String customerEmail);

	@Query(value="SELECT * FROM customer_details WHERE customer_email=:customerEmail",nativeQuery=true)
	public Optional<CustomerDetailsEntity> findByMail(String customerEmail);

	

	

	public boolean existsByCustomerEmail(String customerEmail);

	public boolean existsByCustomerMobileNumber(String customerMobileNumber);

	
}
